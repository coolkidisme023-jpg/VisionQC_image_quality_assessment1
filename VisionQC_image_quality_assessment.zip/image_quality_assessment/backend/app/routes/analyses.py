"""Core VisionQC API: image analysis and analysis history."""

from __future__ import annotations

import logging

from flask import Blueprint, jsonify, request

from app.database import AnalysisRecord, get_db
from app.ml.image_features import ImageDecodeError
from app.services.analyzer import ModelUnavailableError, analyze_image_bytes

logger = logging.getLogger("visionqc.api")

bp = Blueprint("analyses", __name__, url_prefix="/api")


def _error(message: str, status: int, **extra):
    payload = {"error": message, "status": status}
    payload.update(extra)
    return jsonify(payload), status


@bp.route("/analyze", methods=["POST"])
def analyze():
    """Accept a multipart/form-data image upload and return the full
    quality analysis, persisting the result to the database.

    Form field: ``image`` (file). Max size 10 MB. Allowed formats: JPEG,
    PNG, WebP, BMP.
    """
    if "image" not in request.files:
        return _error(
            "No file uploaded. Send the image as multipart/form-data "
            "under the 'image' field.", 400,
        )

    file_storage = request.files["image"]
    if not file_storage or file_storage.filename == "":
        return _error("Uploaded file has no filename.", 400)

    data = file_storage.read()
    filename = file_storage.filename
    content_type = file_storage.mimetype or ""

    try:
        result = analyze_image_bytes(data, filename, content_type)
    except ImageDecodeError as exc:
        logger.info("Rejected upload '%s': %s", filename, exc)
        return _error(str(exc), 400)
    except ModelUnavailableError as exc:
        logger.error("Model unavailable: %s", exc)
        return _error(
            "The quality model is not available on the server. Train it "
            "with 'python training/train_model.py' and restart the "
            "backend.", 503,
        )
    except Exception:  # noqa: BLE001
        logger.exception("Unexpected error analyzing '%s'", filename)
        return _error("Internal error while analyzing the image.", 500)

    record = AnalysisRecord(
        filename=result["filename"],
        predicted_class=result["predicted_class"],
        quality_score=result["quality_score"],
        quality_label=result["quality_label"],
        issues=result["issues"],
        probabilities=result["probabilities"],
        statistics=result["statistics"],
        explainability=result["explainability"],
        model_version=result["model_version"],
    )
    saved = get_db().save_analysis(record)
    return jsonify(saved.to_dict()), 201


@bp.route("/analyses", methods=["GET"])
def list_analyses():
    """Return paginated analysis history, newest first.

    Query params: ``limit`` (default 50, max 200), ``offset`` (default 0).
    """
    try:
        limit = min(int(request.args.get("limit", 50)), 200)
        offset = max(int(request.args.get("offset", 0)), 0)
    except ValueError:
        return _error("'limit' and 'offset' must be integers.", 400)

    db = get_db()
    records = db.list_analyses(limit=limit, offset=offset)
    total = db.count_analyses()
    return jsonify({
        "total": total,
        "limit": limit,
        "offset": offset,
        "items": [r.to_summary_dict() for r in records],
    }), 200


@bp.route("/analyses/<int:analysis_id>", methods=["GET"])
def get_analysis(analysis_id: int):
    """Return the full stored analysis (statistics, probabilities,
    explainability, issues) for a single record."""
    record = get_db().get_analysis(analysis_id)
    if record is None:
        return _error(f"Analysis {analysis_id} not found.", 404)
    return jsonify(record.to_dict()), 200


@bp.route("/analyses/<int:analysis_id>", methods=["DELETE"])
def delete_analysis(analysis_id: int):
    """Delete a stored analysis record."""
    deleted = get_db().delete_analysis(analysis_id)
    if not deleted:
        return _error(f"Analysis {analysis_id} not found.", 404)
    return "", 204

"""Health / liveness endpoint."""

from __future__ import annotations

from datetime import datetime, timezone

from flask import Blueprint, jsonify

from app.config import settings
from app.services.analyzer import is_model_loaded, load_model_bundle

bp = Blueprint("health", __name__)


@bp.route("/health", methods=["GET"])
def health():
    """Liveness/readiness probe.

    Returns 200 with model status even if the model has not been loaded
    into memory yet (it is lazy-loaded on first inference request), but
    reports ``model_ready: false`` and ``model_file_found`` so callers /
    container orchestrators can distinguish "server up, model missing"
    from "fully ready".
    """
    model_file_found = settings.MODEL_PATH.exists()
    return jsonify({
        "status": "ok",
        "service": "visionqc-backend",
        "version": settings.APP_VERSION,
        "model_ready": is_model_loaded(),
        "model_file_found": model_file_found,
        "timestamp": datetime.now(timezone.utc).isoformat(),
    }), 200

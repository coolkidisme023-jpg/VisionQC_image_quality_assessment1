"""API documentation: a hand-authored OpenAPI 3.0 spec served at
``/openapi.json`` plus a dependency-free, self-contained HTML reference
page served at ``/docs``.

Note: FastAPI's automatic ``/docs`` normally embeds the Swagger UI
JavaScript bundle from a CDN. To keep this endpoint fully functional with
zero external network dependency (consistent with the rest of the
application), ``/docs`` here renders a self-contained static reference
page instead of loading Swagger UI from a CDN. The full machine-readable
spec is still available at ``/openapi.json`` for tooling (e.g. importing
into Postman/Insomnia, or a self-hosted Swagger UI).
"""

from __future__ import annotations

from flask import Blueprint, Response, jsonify

from app.config import settings

bp = Blueprint("docs", __name__)


def _openapi_spec() -> dict:
    return {
        "openapi": "3.0.3",
        "info": {
            "title": "VisionQC API",
            "description": "AI-powered image quality & defect detection. "
                            "All inference runs locally; no external AI "
                            "API calls are made.",
            "version": settings.APP_VERSION,
        },
        "servers": [{"url": "/"}],
        "paths": {
            "/health": {
                "get": {
                    "summary": "Health check",
                    "responses": {"200": {"description": "Service is up"}},
                }
            },
            "/api/analyze": {
                "post": {
                    "summary": "Analyze an uploaded image",
                    "requestBody": {
                        "required": True,
                        "content": {
                            "multipart/form-data": {
                                "schema": {
                                    "type": "object",
                                    "properties": {
                                        "image": {"type": "string", "format": "binary"}
                                    },
                                    "required": ["image"],
                                }
                            }
                        },
                    },
                    "responses": {
                        "201": {"description": "Analysis result"},
                        "400": {"description": "Invalid, unreadable, unsupported, or oversized file"},
                        "503": {"description": "Model not available on server"},
                    },
                }
            },
            "/api/analyses": {
                "get": {
                    "summary": "List past analyses (paginated, newest first)",
                    "parameters": [
                        {"name": "limit", "in": "query", "schema": {"type": "integer", "default": 50}},
                        {"name": "offset", "in": "query", "schema": {"type": "integer", "default": 0}},
                    ],
                    "responses": {"200": {"description": "Paginated list"}},
                }
            },
            "/api/analyses/{id}": {
                "get": {
                    "summary": "Get a single analysis by id",
                    "parameters": [{"name": "id", "in": "path", "required": True,
                                     "schema": {"type": "integer"}}],
                    "responses": {"200": {"description": "Full analysis record"},
                                  "404": {"description": "Not found"}},
                },
                "delete": {
                    "summary": "Delete an analysis by id",
                    "parameters": [{"name": "id", "in": "path", "required": True,
                                     "schema": {"type": "integer"}}],
                    "responses": {"204": {"description": "Deleted"},
                                  "404": {"description": "Not found"}},
                },
            },
        },
    }


@bp.route("/openapi.json", methods=["GET"])
def openapi_json():
    return jsonify(_openapi_spec())


_DOCS_HTML = """<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>VisionQC API Docs</title>
<style>
  body { font-family: -apple-system, Segoe UI, Roboto, sans-serif; max-width: 880px;
         margin: 40px auto; padding: 0 20px; color: #1a1a2e; line-height: 1.55; }
  h1 { color: #4338ca; }
  code, pre { background: #f3f4f6; border-radius: 6px; padding: 2px 6px; font-size: 0.92em; }
  pre { padding: 14px; overflow-x: auto; }
  .endpoint { border: 1px solid #e5e7eb; border-radius: 10px; padding: 16px 20px; margin: 18px 0; }
  .method { display: inline-block; font-weight: 700; padding: 2px 10px; border-radius: 6px;
             color: #fff; font-size: 0.82em; margin-right: 8px; }
  .get { background: #10b981; } .post { background: #3b82f6; } .delete { background: #ef4444; }
  a { color: #4338ca; }
</style>
</head>
<body>
<h1>VisionQC API</h1>
<p>AI-Powered Image Quality &amp; Defect Detection - REST API reference.
All inference runs locally (OpenCV + scikit-learn); no external AI/LLM
API is called. Machine-readable spec: <a href="/openapi.json">/openapi.json</a>.</p>

<div class="endpoint"><span class="method get">GET</span><code>/health</code>
<p>Service liveness/readiness check.</p></div>

<div class="endpoint"><span class="method post">POST</span><code>/api/analyze</code>
<p>Upload an image (multipart/form-data, field name <code>image</code>) and
receive a full quality analysis. Max size 10&nbsp;MB. Allowed formats: JPEG, PNG, WebP, BMP.</p>
<pre>curl -F "image=@photo.jpg" http://localhost:8000/api/analyze</pre>
<pre>{
  "id": 1,
  "filename": "photo.jpg",
  "predicted_class": "blur",
  "quality_score": 61.5,
  "quality_label": "DEGRADED",
  "issues": [ {"type": "blur", "severity": "high", "confidence": 0.91,
              "explanation": "...", "statistic": {"name": "laplacian_variance", "value": 18.4} } ],
  "probabilities": {"blur": 0.7, "clean": 0.1, "...": 0.0},
  "statistics": {"mean_brightness": 90.1, "...": 0.0},
  "explainability": {"top_feature_importances": [...]},
  "model_version": "1.0.0",
  "created_at": "2026-01-01T00:00:00+00:00"
}</pre></div>

<div class="endpoint"><span class="method get">GET</span><code>/api/analyses?limit=50&amp;offset=0</code>
<p>Paginated analysis history, newest first.</p></div>

<div class="endpoint"><span class="method get">GET</span><code>/api/analyses/{id}</code>
<p>Full stored analysis by id.</p></div>

<div class="endpoint"><span class="method delete">DELETE</span><code>/api/analyses/{id}</code>
<p>Delete a stored analysis.</p></div>

</body></html>"""


@bp.route("/docs", methods=["GET"])
def docs_page():
    return Response(_DOCS_HTML, mimetype="text/html")

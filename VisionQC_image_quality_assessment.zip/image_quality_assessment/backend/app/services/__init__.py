"""Application services (business logic) for VisionQC."""

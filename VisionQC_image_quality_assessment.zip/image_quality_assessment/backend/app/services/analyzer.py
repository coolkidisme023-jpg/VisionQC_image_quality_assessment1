"""
Inference service: ties together feature extraction, the trained Random
Forest model, quality scoring, rule-based issue detection, and
explainability into a single ``analyze_image_bytes`` entry point used by
the API layer.

Design summary
---------------
1. The engineered features (see ``app.ml.image_features``) are computed
   from the decoded image.
2. Those 16 features are fed into the trained ``StandardScaler +
   RandomForestClassifier`` pipeline (see ``backend/training/train_model.py``)
   to obtain a predicted class and a full probability distribution over
   the 7 quality classes.
3. The probabilities alone are **not** used as the final quality score.
   Per the assignment's explicit requirement, the score combines the
   model's "clean" probability with interpretable statistics (sharpness,
   exposure, noise, structural integrity) using a documented formula -
   see :func:`compute_quality_score`.
4. Issues are detected with a hybrid rule: a statistic must cross an
   interpretable, documented threshold *and/or* the model must assign
   meaningful probability to the corresponding class. This keeps the
   system explainable (a person can verify *why* "blur" was flagged by
   looking at the Laplacian variance) while still benefiting from the
   model's ability to combine many weak signals nonlinearly.
"""

from __future__ import annotations

import threading
from pathlib import Path
from typing import Any, Optional

import joblib
import numpy as np

from app.config import settings
from app.ml.image_features import (
    FEATURE_DESCRIPTIONS,
    FEATURE_NAMES,
    ImageDecodeError,
    decode_image_bytes,
    extract_features,
    validate_upload,
)

# ---------------------------------------------------------------------------
# Model loading (singleton, thread-safe, loaded lazily on first request)
# ---------------------------------------------------------------------------


class ModelUnavailableError(RuntimeError):
    """Raised when the trained model artifact cannot be found or loaded."""


class ModelBundle:
    """Holds the trained pipeline plus its metadata."""

    def __init__(self, pipeline, classes: list[str], version: str):
        self.pipeline = pipeline
        self.classes = classes
        self.version = version


_bundle: Optional[ModelBundle] = None
_bundle_lock = threading.Lock()


def load_model_bundle(force: bool = False) -> ModelBundle:
    global _bundle
    if _bundle is not None and not force:
        return _bundle
    with _bundle_lock:
        if _bundle is not None and not force:
            return _bundle
        model_path: Path = settings.MODEL_PATH
        if not model_path.exists():
            raise ModelUnavailableError(
                f"Trained model not found at {model_path}. Run "
                f"'python training/train_model.py' first."
            )
        pipeline = joblib.load(model_path)
        classes = list(pipeline.named_steps["rf"].classes_)
        version = settings.APP_VERSION
        _bundle = ModelBundle(pipeline=pipeline, classes=classes, version=version)
        return _bundle


def is_model_loaded() -> bool:
    return _bundle is not None


# ---------------------------------------------------------------------------
# Quality score
# ---------------------------------------------------------------------------

# Reference thresholds used to normalize raw statistics into 0-1
# "goodness" sub-scores. These were chosen by inspecting the feature
# distributions produced by the training pipeline (see
# models/model_metadata.json) and standard image-quality-assessment
# literature conventions (e.g. Laplacian-variance blur detection).
SHARPNESS_REF = 250.0          # laplacian_variance at/above this => fully sharp
NOISE_REF = 30.0               # noise_estimate at/above this => fully noisy
BLOCKINESS_REF = 0.35          # blockiness at/above this => fully blocky/corrupted
ENTROPY_REF = 7.2              # entropy at/above this => full information content
DYNAMIC_RANGE_REF = 180.0      # dynamic_range at/above this => full tonal range


def _clamp01(x: float) -> float:
    return float(max(0.0, min(1.0, x)))


def compute_quality_score(features: dict[str, float], probabilities: dict[str, float]) -> float:
    """Compute an interpretable 0-100 quality score.

    The score is a weighted blend of the model's belief that the image is
    clean and four independent, human-checkable sub-scores derived
    directly from the engineered statistics. It deliberately does *not*
    just rescale the model probability, per the assignment brief - a
    statistically sharp, well-exposed image should score well even if the
    classifier is only 55% confident it is "clean" versus, say, "noise".

    Formula
    -------
        score = 100 * (
              0.40 * clean_probability
            + 0.20 * sharpness_score
            + 0.15 * exposure_score
            + 0.15 * noise_score
            + 0.10 * integrity_score
        )

    Where each sub-score is a 0-1 "goodness" value:
        sharpness_score  = clamp(laplacian_variance / SHARPNESS_REF)
        exposure_score   = clamp(1 - 2*dark_pixel_ratio - 2*bright_pixel_ratio)
        noise_score      = clamp(1 - 0.5*(noise_estimate/NOISE_REF)
                                    - 0.5*(blockiness/BLOCKINESS_REF))
        integrity_score  = clamp(0.5*(entropy/ENTROPY_REF)
                                    + 0.5*(dynamic_range/DYNAMIC_RANGE_REF))
    """
    clean_probability = probabilities.get("clean", 0.0)

    sharpness_score = _clamp01(features["laplacian_variance"] / SHARPNESS_REF)
    exposure_score = _clamp01(
        1.0 - 2.0 * features["dark_pixel_ratio"] - 2.0 * features["bright_pixel_ratio"]
    )
    noise_score = _clamp01(
        1.0
        - 0.5 * (features["noise_estimate"] / NOISE_REF)
        - 0.5 * (features["blockiness"] / BLOCKINESS_REF)
    )
    integrity_score = _clamp01(
        0.5 * (features["entropy"] / ENTROPY_REF)
        + 0.5 * (features["dynamic_range"] / DYNAMIC_RANGE_REF)
    )

    raw_score = (
        0.40 * clean_probability
        + 0.20 * sharpness_score
        + 0.15 * exposure_score
        + 0.15 * noise_score
        + 0.10 * integrity_score
    )
    return round(_clamp01(raw_score) * 100, 1)


def quality_label_from_score(score: float) -> str:
    """Map a 0-100 quality score to a human-readable label."""
    if score >= 90:
        return "EXCELLENT"
    if score >= 75:
        return "GOOD"
    if score >= 60:
        return "ACCEPTABLE"
    if score >= 40:
        return "DEGRADED"
    return "SEVERELY_DEGRADED"


# ---------------------------------------------------------------------------
# Issue detection
# ---------------------------------------------------------------------------

def _severity(badness: float) -> str:
    """Map a 0-1 'how bad is it' score to a severity label."""
    if badness >= 0.85:
        return "critical"
    if badness >= 0.60:
        return "high"
    if badness >= 0.35:
        return "medium"
    return "low"


def detect_issues(features: dict[str, float], probabilities: dict[str, float]) -> list[dict[str, Any]]:
    """Return a structured list of detected quality issues.

    Each issue is triggered by an interpretable statistic crossing a
    documented threshold. The model's class probability (when available)
    is blended in as the reported confidence, giving issues both a
    rule-based trigger (for explainability) and a learned confidence
    estimate (for calibration).
    """
    issues: list[dict[str, Any]] = []

    laplacian = features["laplacian_variance"]
    if laplacian < 150:
        badness = _clamp01(1.0 - laplacian / 150.0)
        confidence = max(probabilities.get("blur", 0.0), round(badness, 2))
        issues.append({
            "type": "blur",
            "severity": _severity(badness),
            "confidence": round(float(confidence), 3),
            "explanation": (
                "Low Laplacian variance indicates insufficient image "
                "sharpness (the image lacks fine, high-frequency detail)."
            ),
            "statistic": {"name": "laplacian_variance", "value": round(laplacian, 2)},
        })

    dark_ratio = features["dark_pixel_ratio"]
    mean_brightness = features["mean_brightness"]
    if dark_ratio > 0.30 or mean_brightness < 55:
        badness = _clamp01(max(dark_ratio * 2.2, (55 - mean_brightness) / 55.0))
        confidence = max(probabilities.get("underexposed", 0.0), round(badness, 2))
        issues.append({
            "type": "underexposed",
            "severity": _severity(badness),
            "confidence": round(float(confidence), 3),
            "explanation": (
                "A large fraction of pixels are very dark and overall mean "
                "brightness is low, indicating underexposure."
            ),
            "statistic": {"name": "dark_pixel_ratio", "value": round(dark_ratio, 3)},
        })

    bright_ratio = features["bright_pixel_ratio"]
    if bright_ratio > 0.25 or mean_brightness > 205:
        badness = _clamp01(max(bright_ratio * 2.4, (mean_brightness - 205) / 50.0))
        confidence = max(probabilities.get("overexposed", 0.0), round(badness, 2))
        issues.append({
            "type": "overexposed",
            "severity": _severity(badness),
            "confidence": round(float(confidence), 3),
            "explanation": (
                "A large fraction of pixels are near-saturated (blown out "
                "highlights), indicating overexposure."
            ),
            "statistic": {"name": "bright_pixel_ratio", "value": round(bright_ratio, 3)},
        })

    noise_val = features["noise_estimate"]
    if noise_val > 12.0:
        badness = _clamp01((noise_val - 12.0) / (NOISE_REF - 12.0 + 1e-6))
        confidence = max(probabilities.get("noise", 0.0), round(badness, 2))
        issues.append({
            "type": "noise",
            "severity": _severity(badness),
            "confidence": round(float(confidence), 3),
            "explanation": (
                "High-frequency residual energy after denoising is "
                "elevated, indicating sensor or compression noise."
            ),
            "statistic": {"name": "noise_estimate", "value": round(noise_val, 2)},
        })

    blockiness = features["blockiness"]
    entropy = features["entropy"]
    dyn_range = features["dynamic_range"]
    corrupted_trigger = blockiness > 0.30 or entropy < 4.5 or dyn_range < 60
    if corrupted_trigger:
        badness = _clamp01(max(
            blockiness / BLOCKINESS_REF,
            (4.5 - entropy) / 4.5 if entropy < 4.5 else 0.0,
            (60 - dyn_range) / 60 if dyn_range < 60 else 0.0,
        ))
        confidence = max(probabilities.get("corrupted", 0.0), round(badness, 2))
        issues.append({
            "type": "corrupted",
            "severity": _severity(badness),
            "confidence": round(float(confidence), 3),
            "explanation": (
                "Strong 8x8 block-boundary artifacts, and/or abnormally "
                "low entropy or tonal range, indicate severe compression "
                "damage or file corruption."
            ),
            "statistic": {"name": "blockiness", "value": round(blockiness, 3)},
        })

    # "defect" is inherently localized (a scratch, a dust spot, a dead
    # pixel block) and is not reliably captured by the *global* statistics
    # used above - this is precisely the kind of anomaly the learned
    # Random Forest model is included to catch. We therefore trust the
    # model's probability directly for this class rather than a hand
    # threshold, and only surface it when it is a meaningfully likely
    # explanation for the image (not merely the arg-max among 7 classes).
    defect_prob = probabilities.get("defect", 0.0)
    if defect_prob > 0.30:
        issues.append({
            "type": "defect",
            "severity": _severity(defect_prob),
            "confidence": round(float(defect_prob), 3),
            "explanation": (
                "The trained classifier assigns meaningful probability to "
                "localized visual defects (e.g. scratches, dead-pixel "
                "blocks, sensor dust, or color blotches) based on the "
                "learned combination of texture, edge, and color features."
            ),
            "statistic": {"name": "model_probability_defect", "value": round(defect_prob, 3)},
        })

    # Sort worst-first so the API/UI can show the most severe issue first.
    severity_order = {"critical": 0, "high": 1, "medium": 2, "low": 3}
    issues.sort(key=lambda i: (severity_order[i["severity"]], -i["confidence"]))
    return issues


# ---------------------------------------------------------------------------
# Explainability
# ---------------------------------------------------------------------------

def build_explainability(
    bundle: ModelBundle,
    features: dict[str, float],
    probabilities: dict[str, float],
    predicted_class: str,
    top_k: int = 5,
) -> dict[str, Any]:
    """Assemble the explainability payload returned by the API.

    Exposes: the raw statistics, class probabilities, the predicted class
    and its confidence, and the model's global top-K feature importances
    (Random Forest Gini importance - a real, model-native explainability
    signal, not a post-hoc approximation). We do NOT claim Grad-CAM or any
    saliency-map technique, since the model is a classical Random Forest
    over tabular features and has no spatial gradient to visualize.
    """
    rf = bundle.pipeline.named_steps["rf"]
    importances = rf.feature_importances_
    order = np.argsort(importances)[::-1][:top_k]
    top_importances = [
        {"feature": FEATURE_NAMES[i], "importance": round(float(importances[i]), 4),
         "description": FEATURE_DESCRIPTIONS[FEATURE_NAMES[i]]}
        for i in order
    ]

    return {
        "predicted_class": predicted_class,
        "confidence": round(float(probabilities.get(predicted_class, 0.0)), 3),
        "class_probabilities": {k: round(float(v), 4) for k, v in probabilities.items()},
        "top_feature_importances": top_importances,
        "feature_descriptions": FEATURE_DESCRIPTIONS,
        "model_version": bundle.version,
        "model_type": "RandomForestClassifier (scikit-learn, engineered "
                       "OpenCV/NumPy features - no external AI API used)",
        "note": (
            "Explanations combine the classifier's global feature "
            "importances with directly interpretable per-image "
            "statistics; this is a classical-ML model, so no "
            "Grad-CAM / saliency heatmap is produced."
        ),
    }


# ---------------------------------------------------------------------------
# Full pipeline entry point
# ---------------------------------------------------------------------------

def analyze_image_bytes(data: bytes, filename: str, content_type: str = "") -> dict[str, Any]:
    """Run the full analysis pipeline on raw uploaded bytes.

    Pipeline: validate -> decode -> extract features -> predict ->
    quality score -> issue detection -> explainability. Returns a plain
    dict ready to be JSON-serialized by the API layer and persisted to
    the database.

    Raises ``ImageDecodeError`` for any validation/decoding failure and
    ``ModelUnavailableError`` if the trained model has not been built yet.
    """
    validate_upload(filename, content_type, data)
    image_bgr = decode_image_bytes(data)

    bundle = load_model_bundle()
    feats = extract_features(image_bgr)
    feature_dict = feats.to_dict()
    feature_vector = feats.to_vector().reshape(1, -1)

    proba_row = bundle.pipeline.predict_proba(feature_vector)[0]
    probabilities = {cls: float(p) for cls, p in zip(bundle.classes, proba_row)}
    predicted_class = max(probabilities, key=probabilities.get)

    quality_score = compute_quality_score(feature_dict, probabilities)
    quality_label = quality_label_from_score(quality_score)
    issues = detect_issues(feature_dict, probabilities)
    explainability = build_explainability(bundle, feature_dict, probabilities, predicted_class)

    return {
        "filename": filename,
        "predicted_class": predicted_class,
        "quality_score": quality_score,
        "quality_label": quality_label,
        "issues": issues,
        "probabilities": {k: round(v, 4) for k, v in probabilities.items()},
        "statistics": {k: round(v, 4) for k, v in feature_dict.items()},
        "explainability": explainability,
        "model_version": bundle.version,
    }

"""
Image quality feature extraction.

This module implements a robust, purely local (no external API) feature
extraction pipeline built on OpenCV and NumPy. Every function computes a
single, interpretable statistic about an image that is known in the image
quality assessment (IQA) literature to correlate with a specific visual
defect (blur, exposure problems, noise, compression artifacts, etc).

The 16 features extracted here are used in two places:
    1. As the input vector ``X`` for the trained RandomForestClassifier
       (see ``backend/training/train_model.py``).
    2. Directly, as human-readable evidence in the "explainability" section
       of an API response and in rule-based issue detection
       (see ``backend/app/services/analyzer.py``).

Keeping the feature extraction code standalone (no Flask/DB imports) makes
it trivially reusable from the training script, the inference service, and
unit tests.
"""

from __future__ import annotations

import io
from dataclasses import dataclass, fields
from typing import Dict

import cv2
import numpy as np
from PIL import Image

# ---------------------------------------------------------------------------
# Feature vector definition
# ---------------------------------------------------------------------------

#: Canonical, ordered list of feature names. The ORDER of this list is the
#: order features are fed into the ML model, so it must stay stable across
#: training and inference. Change it only by retraining the model.
FEATURE_NAMES = [
    "mean_brightness",
    "brightness_std",
    "dark_pixel_ratio",
    "bright_pixel_ratio",
    "rms_contrast",
    "laplacian_variance",
    "mean_gradient_magnitude",
    "edge_density",
    "noise_estimate",
    "entropy",
    "mean_saturation",
    "saturation_std",
    "colorfulness",
    "blockiness",
    "texture_energy",
    "dynamic_range",
]

#: Human-readable documentation for each feature, surfaced by the API's
#: explainability endpoint and used to build issue explanations.
FEATURE_DESCRIPTIONS: Dict[str, str] = {
    "mean_brightness": "Average pixel intensity (0-255). Very low or very "
                        "high values indicate under/over-exposure.",
    "brightness_std": "Standard deviation of pixel intensity. Low values "
                       "indicate a flat, low-contrast image.",
    "dark_pixel_ratio": "Fraction of pixels below an intensity threshold "
                         "(30/255). High values indicate underexposure.",
    "bright_pixel_ratio": "Fraction of pixels above an intensity threshold "
                           "(225/255). High values indicate overexposure "
                           "or blown-out highlights.",
    "rms_contrast": "Root-mean-square contrast; the normalized standard "
                     "deviation of intensity. Low contrast can indicate "
                     "haze, fog, or a washed-out image.",
    "laplacian_variance": "Variance of the Laplacian (2nd derivative) of "
                           "the image. The single strongest classical "
                           "sharpness indicator - low values mean blur.",
    "mean_gradient_magnitude": "Average Sobel gradient magnitude. Low "
                                "values indicate a lack of fine detail "
                                "(blur or over-smoothing).",
    "edge_density": "Fraction of pixels detected as edges by the Canny "
                     "detector. Measures structural / textural detail.",
    "noise_estimate": "High-frequency residual energy left after "
                       "denoising (median filter subtraction). High "
                       "values indicate sensor or compression noise.",
    "entropy": "Shannon entropy of the intensity histogram. Measures "
                "information content / complexity; very low entropy can "
                "indicate a corrupted, blank, or degenerate image.",
    "mean_saturation": "Average saturation channel value in HSV space. "
                        "Very low values indicate a washed-out or "
                        "near-grayscale image.",
    "saturation_std": "Standard deviation of saturation. Low values "
                       "combined with low mean saturation reinforce a "
                       "washed-out / faded diagnosis.",
    "colorfulness": "Hasler-Susstrunk colorfulness metric computed from "
                     "the opponent color channels. Very low values can "
                     "indicate desaturation or a monochrome/defective "
                     "capture.",
    "blockiness": "Estimate of 8x8 JPEG blockiness: the ratio of gradient "
                   "energy aligned to block boundaries versus interior "
                   "gradient energy. High values indicate heavy "
                   "compression artifacts / corruption.",
    "texture_energy": "Local variance of a high-pass filtered image "
                       "(texture energy). Near-zero values indicate flat, "
                       "featureless, or severely degraded regions.",
    "dynamic_range": "Difference between the 99th and 1st percentile "
                      "intensity values. Low dynamic range indicates poor "
                      "tonal quality (flat, foggy, or corrupted images).",
}

MAX_UPLOAD_BYTES = 10 * 1024 * 1024  # 10 MB
ALLOWED_CONTENT_TYPES = {
    "image/jpeg",
    "image/png",
    "image/webp",
    "image/bmp",
    "image/x-ms-bmp",
}
ALLOWED_EXTENSIONS = {".jpg", ".jpeg", ".png", ".webp", ".bmp"}


class ImageDecodeError(ValueError):
    """Raised when uploaded bytes cannot be decoded as a supported image."""


@dataclass
class ImageFeatures:
    """Typed container for the 16 engineered image-quality features."""

    mean_brightness: float
    brightness_std: float
    dark_pixel_ratio: float
    bright_pixel_ratio: float
    rms_contrast: float
    laplacian_variance: float
    mean_gradient_magnitude: float
    edge_density: float
    noise_estimate: float
    entropy: float
    mean_saturation: float
    saturation_std: float
    colorfulness: float
    blockiness: float
    texture_energy: float
    dynamic_range: float

    def to_dict(self) -> Dict[str, float]:
        return {f.name: float(getattr(self, f.name)) for f in fields(self)}

    def to_vector(self) -> np.ndarray:
        """Return features as a 1D numpy array in FEATURE_NAMES order."""
        return np.array([getattr(self, name) for name in FEATURE_NAMES], dtype=np.float64)


# ---------------------------------------------------------------------------
# Decoding helpers
# ---------------------------------------------------------------------------

def decode_image_bytes(data: bytes) -> np.ndarray:
    """Decode raw image bytes into a BGR OpenCV image (uint8, HxWx3).

    Raises ``ImageDecodeError`` for empty, truncated, or unreadable data.
    This is deliberately defensive: uploaded files may be partially
    corrupted, use an unsupported format, or simply not be images at all.
    """
    if not data:
        raise ImageDecodeError("Uploaded file is empty.")

    # First try Pillow, which gives friendlier errors and verifies the
    # container/format. Then convert to OpenCV's BGR convention.
    try:
        with Image.open(io.BytesIO(data)) as pil_img:
            pil_img.verify()  # checks structural integrity without full decode
        with Image.open(io.BytesIO(data)) as pil_img:
            pil_img = pil_img.convert("RGB")
            rgb = np.array(pil_img)
    except Exception as exc:  # noqa: BLE001 - we re-raise as a domain error
        raise ImageDecodeError(f"Could not decode image: {exc}") from exc

    if rgb.size == 0 or rgb.ndim != 3:
        raise ImageDecodeError("Decoded image has invalid dimensions.")

    bgr = cv2.cvtColor(rgb, cv2.COLOR_RGB2BGR)
    return bgr


def validate_upload(filename: str, content_type: str, data: bytes) -> None:
    """Validate an uploaded file before attempting to decode it.

    Raises ``ImageDecodeError`` with a human-readable message on failure.
    """
    if data is None or len(data) == 0:
        raise ImageDecodeError("Uploaded file is empty.")
    if len(data) > MAX_UPLOAD_BYTES:
        raise ImageDecodeError(
            f"File exceeds the maximum upload size of "
            f"{MAX_UPLOAD_BYTES // (1024 * 1024)} MB."
        )
    ext = ("." + filename.rsplit(".", 1)[-1].lower()) if "." in filename else ""
    if ext not in ALLOWED_EXTENSIONS:
        raise ImageDecodeError(
            f"Unsupported file extension '{ext}'. Allowed: "
            f"{', '.join(sorted(ALLOWED_EXTENSIONS))}."
        )


# ---------------------------------------------------------------------------
# Individual feature computations
# ---------------------------------------------------------------------------

def _colorfulness(image_bgr: np.ndarray) -> float:
    """Hasler & Susstrunk (2003) colorfulness metric."""
    b, g, r = cv2.split(image_bgr.astype("float32"))
    rg = r - g
    yb = 0.5 * (r + g) - b
    std_rg, mean_rg = np.std(rg), np.mean(rg)
    std_yb, mean_yb = np.std(yb), np.mean(yb)
    std_root = np.sqrt(std_rg ** 2 + std_yb ** 2)
    mean_root = np.sqrt(mean_rg ** 2 + mean_yb ** 2)
    return float(std_root + 0.3 * mean_root)


def _blockiness(gray: np.ndarray) -> float:
    """Estimate JPEG 8x8 blockiness.

    Compares the average absolute gradient magnitude across 8-pixel-aligned
    block boundaries against the average gradient magnitude everywhere
    else. Heavily compressed / corrupted images show a distinctly higher
    ratio because DCT quantization introduces sharp discontinuities every
    8 pixels.
    """
    gray = gray.astype(np.float32)
    h, w = gray.shape

    # Horizontal differences (columns) and vertical differences (rows)
    diff_h = np.abs(np.diff(gray, axis=1))  # shape (h, w-1)
    diff_v = np.abs(np.diff(gray, axis=0))  # shape (h-1, w)

    col_idx = np.arange(diff_h.shape[1])
    row_idx = np.arange(diff_v.shape[0])

    block_cols = (col_idx % 8) == 7  # boundary between block n and n+1
    block_rows = (row_idx % 8) == 7

    if block_cols.sum() == 0 or block_rows.sum() == 0 or (~block_cols).sum() == 0:
        return 0.0

    boundary_energy = diff_h[:, block_cols].mean() + diff_v[block_rows, :].mean()
    interior_energy = diff_h[:, ~block_cols].mean() + diff_v[~block_rows, :].mean()

    if interior_energy < 1e-6:
        return 0.0
    ratio = (boundary_energy / interior_energy) - 1.0
    return float(max(0.0, ratio))


def _noise_estimate(gray: np.ndarray) -> float:
    """Estimate noise energy as the residual after median denoising."""
    denoised = cv2.medianBlur(gray, 3)
    residual = gray.astype(np.float32) - denoised.astype(np.float32)
    return float(np.std(residual))


def _entropy(gray: np.ndarray) -> float:
    hist = cv2.calcHist([gray], [0], None, [256], [0, 256]).flatten()
    hist = hist / (hist.sum() + 1e-12)
    hist = hist[hist > 0]
    return float(-np.sum(hist * np.log2(hist)))


def _texture_energy(gray: np.ndarray) -> float:
    """Local variance of a high-pass filtered version of the image."""
    blurred = cv2.GaussianBlur(gray, (5, 5), 0)
    high_pass = gray.astype(np.float32) - blurred.astype(np.float32)
    return float(np.var(high_pass))


def extract_features(image_bgr: np.ndarray) -> ImageFeatures:
    """Compute the full 16-dimensional feature vector for a BGR image."""
    if image_bgr is None or image_bgr.size == 0:
        raise ImageDecodeError("Cannot extract features from an empty image.")

    # Normalize working size so features are roughly scale-invariant and
    # extraction stays fast for very large uploads.
    h, w = image_bgr.shape[:2]
    max_dim = 1024
    if max(h, w) > max_dim:
        scale = max_dim / max(h, w)
        image_bgr = cv2.resize(image_bgr, (int(w * scale), int(h * scale)),
                                interpolation=cv2.INTER_AREA)

    gray = cv2.cvtColor(image_bgr, cv2.COLOR_BGR2GRAY)
    hsv = cv2.cvtColor(image_bgr, cv2.COLOR_BGR2HSV)

    # --- brightness / exposure -------------------------------------------------
    mean_brightness = float(np.mean(gray))
    brightness_std = float(np.std(gray))
    dark_pixel_ratio = float(np.mean(gray < 30))
    bright_pixel_ratio = float(np.mean(gray > 225))
    rms_contrast = float(np.std(gray.astype(np.float32)) / 255.0)

    p1, p99 = np.percentile(gray, [1, 99])
    dynamic_range = float(p99 - p1)

    # --- sharpness / structure ---------------------------------------------
    laplacian_variance = float(cv2.Laplacian(gray, cv2.CV_64F).var())

    sobel_x = cv2.Sobel(gray, cv2.CV_64F, 1, 0, ksize=3)
    sobel_y = cv2.Sobel(gray, cv2.CV_64F, 0, 1, ksize=3)
    gradient_magnitude = np.sqrt(sobel_x ** 2 + sobel_y ** 2)
    mean_gradient_magnitude = float(np.mean(gradient_magnitude))

    edges = cv2.Canny(gray, 100, 200)
    edge_density = float(np.mean(edges > 0))

    texture_energy = _texture_energy(gray)

    # --- noise / degradation -------------------------------------------------
    noise_estimate = _noise_estimate(gray)
    blockiness = _blockiness(gray)
    entropy = _entropy(gray)

    # --- color -----------------------------------------------------------------
    saturation = hsv[:, :, 1].astype(np.float32)
    mean_saturation = float(np.mean(saturation))
    saturation_std = float(np.std(saturation))
    colorfulness = _colorfulness(image_bgr)

    return ImageFeatures(
        mean_brightness=mean_brightness,
        brightness_std=brightness_std,
        dark_pixel_ratio=dark_pixel_ratio,
        bright_pixel_ratio=bright_pixel_ratio,
        rms_contrast=rms_contrast,
        laplacian_variance=laplacian_variance,
        mean_gradient_magnitude=mean_gradient_magnitude,
        edge_density=edge_density,
        noise_estimate=noise_estimate,
        entropy=entropy,
        mean_saturation=mean_saturation,
        saturation_std=saturation_std,
        colorfulness=colorfulness,
        blockiness=blockiness,
        texture_energy=texture_energy,
        dynamic_range=dynamic_range,
    )

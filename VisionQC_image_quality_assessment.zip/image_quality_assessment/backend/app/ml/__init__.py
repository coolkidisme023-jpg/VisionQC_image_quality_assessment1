"""Machine-learning and computer-vision components of VisionQC."""

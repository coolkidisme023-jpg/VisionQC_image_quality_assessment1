import { mountAnalyzePage } from "./pages/analyzePage.js";
import { mountHistoryPage } from "./pages/historyPage.js";
import { checkHealth } from "./services/api.js";

const routes = {
  "#/analyze": { label: "Analyze", mount: mountAnalyzePage },
  "#/history": { label: "History", mount: mountHistoryPage },
};

function currentRoute() {
  const hash = window.location.hash || "#/analyze";
  return routes[hash] ? hash : "#/analyze";
}

function renderNav(active) {
  const nav = document.getElementById("main-nav");
  nav.innerHTML = Object.entries(routes)
    .map(
      ([hash, r]) =>
        `<a href="${hash}" class="nav-link ${hash === active ? "active" : ""}">${r.label}</a>`,
    )
    .join("");
}

async function router() {
  const hash = currentRoute();
  renderNav(hash);
  const root = document.getElementById("page-root");
  await routes[hash].mount(root);
}

async function checkBackendStatus() {
  const pill = document.getElementById("backend-status-pill");
  try {
    const health = await checkHealth();
    if (health.model_ready || health.model_file_found) {
      pill.textContent = "● Backend connected";
      pill.className = "backend-pill backend-ok";
    } else {
      pill.textContent = "● Model not trained";
      pill.className = "backend-pill backend-warn";
    }
  } catch {
    pill.textContent = "● Backend unavailable";
    pill.className = "backend-pill backend-error";
  }
}

window.addEventListener("hashchange", router);
window.addEventListener("DOMContentLoaded", () => {
  router();
  checkBackendStatus();
  setInterval(checkBackendStatus, 30000);
});

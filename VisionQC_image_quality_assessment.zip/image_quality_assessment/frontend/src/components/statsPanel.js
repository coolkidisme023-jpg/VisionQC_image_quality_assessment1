/**
 * Renders the statistics table, class-probability bars, and
 * explainability (top feature importances) panels.
 */

function escapeHtml(str) {
  const div = document.createElement("div");
  div.textContent = String(str);
  return div.innerHTML;
}

export function renderProbabilities(probabilities, predictedClass) {
  const entries = Object.entries(probabilities).sort((a, b) => b[1] - a[1]);
  const rows = entries
    .map(([cls, p]) => {
      const pct = (p * 100).toFixed(1);
      const isTop = cls === predictedClass;
      return `
        <div class="prob-row ${isTop ? "prob-row-top" : ""}">
          <span class="prob-label">${escapeHtml(cls)}</span>
          <div class="prob-bar-track">
            <div class="prob-bar-fill" style="width:${pct}%"></div>
          </div>
          <span class="prob-value">${pct}%</span>
        </div>`;
    })
    .join("");
  return `<div class="prob-panel">${rows}</div>`;
}

export function renderStatistics(statistics) {
  const rows = Object.entries(statistics)
    .map(
      ([name, value]) => `
      <div class="stat-row">
        <span class="stat-name">${escapeHtml(name.replace(/_/g, " "))}</span>
        <span class="stat-value">${typeof value === "number" ? value.toFixed(3) : value}</span>
      </div>`,
    )
    .join("");
  return `<div class="stats-panel">${rows}</div>`;
}

export function renderExplainability(explainability) {
  const importanceRows = (explainability.top_feature_importances || [])
    .map(
      (fi) => `
      <div class="importance-row">
        <div class="importance-header">
          <span class="importance-feature">${escapeHtml(fi.feature.replace(/_/g, " "))}</span>
          <span class="importance-value">${(fi.importance * 100).toFixed(1)}%</span>
        </div>
        <div class="importance-bar-track">
          <div class="importance-bar-fill" style="width:${(fi.importance * 100).toFixed(1)}%"></div>
        </div>
        <p class="importance-desc">${escapeHtml(fi.description)}</p>
      </div>`,
    )
    .join("");

  return `
    <div class="explain-panel">
      <p class="explain-note">${escapeHtml(explainability.note || "")}</p>
      <h4>Top model feature importances</h4>
      ${importanceRows}
      <p class="explain-model-type">${escapeHtml(explainability.model_type || "")}</p>
    </div>
  `;
}

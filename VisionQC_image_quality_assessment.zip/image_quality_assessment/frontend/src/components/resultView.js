import { renderScoreGauge, scoreColor } from "./scoreGauge.js";
import { renderIssueList } from "./issueCard.js";
import { renderProbabilities, renderStatistics, renderExplainability } from "./statsPanel.js";

export function fmtDate(iso) {
  try {
    return new Date(iso).toLocaleString();
  } catch {
    return iso;
  }
}

/** Renders the full analysis result (score gauge, issues, probabilities,
 * statistics, explainability) into `container`. Shared by the Analyze
 * page (fresh result) and the History page (viewing a past record). */
export function renderResult(container, result) {
  const color = scoreColor(result.quality_label);
  container.innerHTML = `
    <div class="result-grid">
      <div class="result-card result-summary">
        <div class="result-summary-top">
          ${renderScoreGauge(result.quality_score, result.quality_label)}
          <div class="result-summary-text">
            <span class="quality-badge" style="background:${color}">${result.quality_label.replace(/_/g, " ")}</span>
            <h2 class="predicted-class">${result.predicted_class.replace(/_/g, " ")}</h2>
            <p class="result-filename">${result.filename}</p>
            <p class="result-timestamp">Analyzed ${fmtDate(result.created_at)} &middot; model v${result.model_version}</p>
          </div>
        </div>
      </div>

      <div class="result-card">
        <h3>Detected issues</h3>
        ${renderIssueList(result.issues)}
      </div>

      <div class="result-card">
        <h3>Class probabilities</h3>
        ${renderProbabilities(result.probabilities, result.predicted_class)}
      </div>

      <div class="result-card">
        <h3>Image statistics</h3>
        ${renderStatistics(result.statistics)}
      </div>

      <div class="result-card result-card-wide">
        <h3>Explainability</h3>
        ${renderExplainability(result.explainability)}
      </div>
    </div>
  `;
}

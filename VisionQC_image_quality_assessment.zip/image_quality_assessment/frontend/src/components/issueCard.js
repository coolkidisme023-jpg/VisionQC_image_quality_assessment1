/**
 * Renders a single detected-issue card.
 */

const SEVERITY_ICON = {
  critical: "⛔", // no entry
  high: "⚠️", // warning
  medium: "▲", // triangle
  low: "ℹ️", // info
};

const ISSUE_ICON = {
  blur: "\u{1F4F7}",
  underexposed: "\u{1F31A}",
  overexposed: "☀️",
  noise: "\u{1F4FA}",
  corrupted: "\u{1F480}",
  defect: "\u{1F50D}",
};

function escapeHtml(str) {
  const div = document.createElement("div");
  div.textContent = str;
  return div.innerHTML;
}

export function renderIssueCard(issue) {
  const icon = ISSUE_ICON[issue.type] || "❗";
  const sevIcon = SEVERITY_ICON[issue.severity] || "";
  const confidencePct = Math.round(issue.confidence * 100);

  return `
    <div class="issue-card severity-${issue.severity}">
      <div class="issue-card-header">
        <span class="issue-icon">${icon}</span>
        <span class="issue-type">${escapeHtml(issue.type.replace(/_/g, " "))}</span>
        <span class="issue-severity-badge severity-${issue.severity}">${sevIcon} ${issue.severity}</span>
      </div>
      <p class="issue-explanation">${escapeHtml(issue.explanation)}</p>
      <div class="issue-meta">
        <span>Confidence: <strong>${confidencePct}%</strong></span>
        <span>${escapeHtml(issue.statistic.name)}: <strong>${issue.statistic.value}</strong></span>
      </div>
      <div class="confidence-bar-track">
        <div class="confidence-bar-fill severity-${issue.severity}" style="width:${confidencePct}%"></div>
      </div>
    </div>
  `;
}

export function renderIssueList(issues) {
  if (!issues || issues.length === 0) {
    return `<div class="no-issues">✅ No significant quality issues detected.</div>`;
  }
  return `<div class="issue-list">${issues.map(renderIssueCard).join("")}</div>`;
}

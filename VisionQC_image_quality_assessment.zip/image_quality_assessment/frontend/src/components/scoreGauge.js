/**
 * Renders a circular SVG "gauge ring" for the 0-100 quality score.
 * Pure function: score + label in, an HTML string out.
 */

const LABEL_COLORS = {
  EXCELLENT: "#10b981",
  GOOD: "#22c55e",
  ACCEPTABLE: "#eab308",
  DEGRADED: "#f97316",
  SEVERELY_DEGRADED: "#ef4444",
};

export function scoreColor(label) {
  return LABEL_COLORS[label] || "#6366f1";
}

export function renderScoreGauge(score, label, size = 168) {
  const radius = (size - 16) / 2;
  const circumference = 2 * Math.PI * radius;
  const clamped = Math.max(0, Math.min(100, score));
  const offset = circumference * (1 - clamped / 100);
  const color = scoreColor(label);
  const center = size / 2;

  return `
    <svg width="${size}" height="${size}" viewBox="0 0 ${size} ${size}" class="score-gauge" role="img" aria-label="Quality score ${clamped} out of 100">
      <circle cx="${center}" cy="${center}" r="${radius}" class="gauge-track" fill="none" stroke-width="12"></circle>
      <circle
        cx="${center}" cy="${center}" r="${radius}"
        fill="none" stroke="${color}" stroke-width="12"
        stroke-linecap="round"
        stroke-dasharray="${circumference}"
        stroke-dashoffset="${offset}"
        transform="rotate(-90 ${center} ${center})"
        class="gauge-progress"
      ></circle>
      <text x="50%" y="46%" text-anchor="middle" class="gauge-score">${clamped.toFixed(1)}</text>
      <text x="50%" y="62%" text-anchor="middle" class="gauge-max">/ 100</text>
    </svg>
  `;
}

import { analyzeImage, ApiError } from "../services/api.js";
import { renderResult } from "../components/resultView.js";

const MAX_BYTES = 10 * 1024 * 1024;
const ALLOWED_TYPES = ["image/jpeg", "image/png", "image/webp", "image/bmp", "image/x-ms-bmp"];
const ALLOWED_EXT = [".jpg", ".jpeg", ".png", ".webp", ".bmp"];

function fmtBytes(bytes) {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(2)} MB`;
}

function fmtDate(iso) {
  try {
    return new Date(iso).toLocaleString();
  } catch {
    return iso;
  }
}

export function mountAnalyzePage(root) {
  root.innerHTML = `
    <section class="analyze-page">
      <div class="upload-card" id="upload-card">
        <div class="dropzone" id="dropzone" tabindex="0" role="button" aria-label="Upload an image">
          <input type="file" id="file-input" accept=".jpg,.jpeg,.png,.webp,.bmp" hidden />
          <div class="dropzone-empty" id="dropzone-empty">
            <div class="dropzone-icon">📤</div>
            <p><strong>Drag &amp; drop an image here</strong></p>
            <p class="dropzone-sub">or</p>
            <button type="button" class="btn btn-primary" id="browse-btn">Browse files</button>
            <p class="dropzone-hint">JPEG, PNG, WebP, or BMP &middot; up to 10&nbsp;MB</p>
          </div>
          <div class="dropzone-preview" id="dropzone-preview" hidden>
            <img id="preview-img" alt="Selected image preview" />
            <div class="preview-meta" id="preview-meta"></div>
          </div>
        </div>

        <div class="upload-actions">
          <button type="button" class="btn btn-primary btn-lg" id="analyze-btn" disabled>
            Analyze image
          </button>
          <button type="button" class="btn btn-ghost" id="clear-btn" hidden>Choose another image</button>
        </div>

        <div class="state-banner state-loading" id="loading-banner" hidden>
          <span class="spinner"></span> Uploading &amp; analyzing image&hellip;
        </div>
        <div class="state-banner state-error" id="error-banner" hidden></div>
      </div>

      <div class="result-area" id="result-area" hidden></div>
    </section>
  `;

  const dropzone = root.querySelector("#dropzone");
  const fileInput = root.querySelector("#file-input");
  const browseBtn = root.querySelector("#browse-btn");
  const analyzeBtn = root.querySelector("#analyze-btn");
  const clearBtn = root.querySelector("#clear-btn");
  const dropzoneEmpty = root.querySelector("#dropzone-empty");
  const dropzonePreview = root.querySelector("#dropzone-preview");
  const previewImg = root.querySelector("#preview-img");
  const previewMeta = root.querySelector("#preview-meta");
  const loadingBanner = root.querySelector("#loading-banner");
  const errorBanner = root.querySelector("#error-banner");
  const resultArea = root.querySelector("#result-area");

  let selectedFile = null;

  function showError(message) {
    errorBanner.textContent = `❌ ${message}`;
    errorBanner.hidden = false;
  }
  function clearError() {
    errorBanner.hidden = true;
    errorBanner.textContent = "";
  }

  function validateClientSide(file) {
    const ext = "." + file.name.split(".").pop().toLowerCase();
    if (!ALLOWED_EXT.includes(ext)) {
      return `Unsupported file type '${ext}'. Allowed: ${ALLOWED_EXT.join(", ")}.`;
    }
    if (file.size > MAX_BYTES) {
      return `File is ${fmtBytes(file.size)}, which exceeds the 10 MB limit.`;
    }
    if (file.size === 0) {
      return "The selected file is empty.";
    }
    return null;
  }

  function selectFile(file) {
    clearError();
    resultArea.hidden = true;
    resultArea.innerHTML = "";

    const validationError = validateClientSide(file);
    if (validationError) {
      showError(validationError);
      selectedFile = null;
      analyzeBtn.disabled = true;
      return;
    }

    selectedFile = file;
    const url = URL.createObjectURL(file);
    previewImg.src = url;
    previewMeta.textContent = `${file.name} · ${fmtBytes(file.size)}`;
    dropzoneEmpty.hidden = true;
    dropzonePreview.hidden = false;
    clearBtn.hidden = false;
    analyzeBtn.disabled = false;
  }

  function resetUpload() {
    selectedFile = null;
    fileInput.value = "";
    dropzoneEmpty.hidden = false;
    dropzonePreview.hidden = true;
    clearBtn.hidden = true;
    analyzeBtn.disabled = true;
    resultArea.hidden = true;
    resultArea.innerHTML = "";
    clearError();
  }

  browseBtn.addEventListener("click", () => fileInput.click());
  dropzone.addEventListener("click", (e) => {
    if (e.target === dropzone || e.target === dropzoneEmpty) fileInput.click();
  });
  dropzone.addEventListener("keydown", (e) => {
    if (e.key === "Enter" || e.key === " ") fileInput.click();
  });

  fileInput.addEventListener("change", () => {
    if (fileInput.files && fileInput.files[0]) selectFile(fileInput.files[0]);
  });

  ["dragenter", "dragover"].forEach((evt) =>
    dropzone.addEventListener(evt, (e) => {
      e.preventDefault();
      dropzone.classList.add("dragover");
    }),
  );
  ["dragleave", "drop"].forEach((evt) =>
    dropzone.addEventListener(evt, (e) => {
      e.preventDefault();
      dropzone.classList.remove("dragover");
    }),
  );
  dropzone.addEventListener("drop", (e) => {
    const file = e.dataTransfer.files && e.dataTransfer.files[0];
    if (file) selectFile(file);
  });

  clearBtn.addEventListener("click", resetUpload);

  analyzeBtn.addEventListener("click", async () => {
    if (!selectedFile) return;
    clearError();
    loadingBanner.hidden = false;
    analyzeBtn.disabled = true;
    resultArea.hidden = true;

    try {
      const result = await analyzeImage(selectedFile);
      renderResult(resultArea, result);
      resultArea.hidden = false;
    } catch (err) {
      if (err instanceof ApiError) {
        showError(err.message);
      } else {
        showError("Unexpected error while analyzing the image.");
        console.error(err);
      }
    } finally {
      loadingBanner.hidden = true;
      analyzeBtn.disabled = false;
    }
  });

  return { resetUpload };
}

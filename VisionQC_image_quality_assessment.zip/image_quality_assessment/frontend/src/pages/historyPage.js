import { fetchHistory, fetchAnalysis, deleteAnalysis, ApiError } from "../services/api.js";
import { renderResult, fmtDate } from "../components/resultView.js";
import { scoreColor } from "../components/scoreGauge.js";

const PAGE_SIZE = 20;

export async function mountHistoryPage(root) {
  root.innerHTML = `
    <section class="history-page">
      <div class="history-list-card">
        <div class="history-header">
          <h2>Analysis history</h2>
          <button class="btn btn-ghost" id="refresh-history-btn">↻ Refresh</button>
        </div>
        <div id="history-state"></div>
        <div class="history-table-wrap">
          <table class="history-table" id="history-table" hidden>
            <thead>
              <tr>
                <th>Filename</th>
                <th>Date</th>
                <th>Score</th>
                <th>Status</th>
                <th>Condition</th>
                <th></th>
              </tr>
            </thead>
            <tbody id="history-tbody"></tbody>
          </table>
        </div>
        <div class="history-pagination" id="history-pagination" hidden>
          <button class="btn btn-ghost" id="prev-page-btn">← Previous</button>
          <span id="page-info"></span>
          <button class="btn btn-ghost" id="next-page-btn">Next →</button>
        </div>
      </div>
      <div class="history-detail-card" id="history-detail" hidden>
        <div class="history-detail-header">
          <h2>Analysis detail</h2>
          <button class="btn btn-ghost" id="close-detail-btn">✕ Close</button>
        </div>
        <div id="history-detail-body"></div>
      </div>
    </section>
  `;

  const stateEl = root.querySelector("#history-state");
  const table = root.querySelector("#history-table");
  const tbody = root.querySelector("#history-tbody");
  const pagination = root.querySelector("#history-pagination");
  const pageInfo = root.querySelector("#page-info");
  const prevBtn = root.querySelector("#prev-page-btn");
  const nextBtn = root.querySelector("#next-page-btn");
  const detailCard = root.querySelector("#history-detail");
  const detailBody = root.querySelector("#history-detail-body");
  const closeDetailBtn = root.querySelector("#close-detail-btn");
  const refreshBtn = root.querySelector("#refresh-history-btn");

  let offset = 0;
  let total = 0;

  async function load() {
    stateEl.innerHTML = `<div class="state-banner state-loading"><span class="spinner"></span> Loading history&hellip;</div>`;
    table.hidden = true;
    pagination.hidden = true;

    try {
      const data = await fetchHistory({ limit: PAGE_SIZE, offset });
      total = data.total;
      stateEl.innerHTML = "";

      if (data.items.length === 0) {
        stateEl.innerHTML = `<div class="empty-state">📭 No analyses yet. Upload an image on the Analyze tab to get started.</div>`;
        return;
      }

      tbody.innerHTML = data.items
        .map(
          (item) => `
        <tr data-id="${item.id}" class="history-row" tabindex="0">
          <td>${escapeHtml(item.filename)}</td>
          <td>${fmtDate(item.created_at)}</td>
          <td><strong>${item.quality_score.toFixed(1)}</strong></td>
          <td><span class="status-pill" style="background:${scoreColor(item.quality_label)}">${item.quality_label.replace(/_/g, " ")}</span></td>
          <td>${escapeHtml(item.predicted_class.replace(/_/g, " "))}</td>
          <td><button class="btn-icon delete-row-btn" data-id="${item.id}" title="Delete">🗑</button></td>
        </tr>`,
        )
        .join("");

      table.hidden = false;
      pagination.hidden = false;
      const start = offset + 1;
      const end = Math.min(offset + PAGE_SIZE, total);
      pageInfo.textContent = `${start}-${end} of ${total}`;
      prevBtn.disabled = offset === 0;
      nextBtn.disabled = end >= total;
    } catch (err) {
      const message = err instanceof ApiError ? err.message : "Failed to load history.";
      stateEl.innerHTML = `<div class="state-banner state-error">❌ ${escapeHtml(message)}</div>`;
    }
  }

  tbody.addEventListener("click", async (e) => {
    const delBtn = e.target.closest(".delete-row-btn");
    if (delBtn) {
      e.stopPropagation();
      const id = delBtn.dataset.id;
      if (confirm(`Delete analysis #${id}? This cannot be undone.`)) {
        try {
          await deleteAnalysis(id);
          await load();
        } catch (err) {
          alert(err.message || "Could not delete analysis.");
        }
      }
      return;
    }
    const row = e.target.closest(".history-row");
    if (row) await showDetail(row.dataset.id);
  });

  async function showDetail(id) {
    detailCard.hidden = false;
    detailBody.innerHTML = `<div class="state-banner state-loading"><span class="spinner"></span> Loading analysis #${id}&hellip;</div>`;
    detailCard.scrollIntoView({ behavior: "smooth", block: "nearest" });
    try {
      const result = await fetchAnalysis(id);
      renderResult(detailBody, result);
    } catch (err) {
      detailBody.innerHTML = `<div class="state-banner state-error">❌ ${escapeHtml(err.message || "Could not load analysis.")}</div>`;
    }
  }

  closeDetailBtn.addEventListener("click", () => {
    detailCard.hidden = true;
    detailBody.innerHTML = "";
  });

  refreshBtn.addEventListener("click", load);
  prevBtn.addEventListener("click", () => {
    offset = Math.max(0, offset - PAGE_SIZE);
    load();
  });
  nextBtn.addEventListener("click", () => {
    offset += PAGE_SIZE;
    load();
  });

  await load();
}

function escapeHtml(str) {
  const div = document.createElement("div");
  div.textContent = String(str);
  return div.innerHTML;
}

/**
 * Thin fetch-based API client for the VisionQC backend.
 * (Plain Fetch API is used instead of axios - no npm install is available/
 * needed for a build-free vanilla-JS frontend; Fetch covers everything
 * this app needs.)
 */

const API_BASE = window.__VISIONQC_API_BASE__ || "http://localhost:8000";

class ApiError extends Error {
  constructor(message, status) {
    super(message);
    this.name = "ApiError";
    this.status = status;
  }
}

async function parseJsonSafe(response) {
  try {
    return await response.json();
  } catch {
    return null;
  }
}

export async function checkHealth() {
  const response = await fetch(`${API_BASE}/health`, { method: "GET" });
  if (!response.ok) throw new ApiError("Backend health check failed", response.status);
  return response.json();
}

export async function analyzeImage(file, { onUploadStart } = {}) {
  const formData = new FormData();
  formData.append("image", file, file.name);

  if (onUploadStart) onUploadStart();

  let response;
  try {
    response = await fetch(`${API_BASE}/api/analyze`, {
      method: "POST",
      body: formData,
    });
  } catch (networkError) {
    throw new ApiError(
      "Could not reach the VisionQC backend. Is it running and reachable at " +
        API_BASE + "?",
      0,
    );
  }

  const body = await parseJsonSafe(response);
  if (!response.ok) {
    const message = body?.error || `Analysis failed (HTTP ${response.status}).`;
    throw new ApiError(message, response.status);
  }
  return body;
}

export async function fetchHistory({ limit = 50, offset = 0 } = {}) {
  const response = await fetch(
    `${API_BASE}/api/analyses?limit=${limit}&offset=${offset}`,
  );
  const body = await parseJsonSafe(response);
  if (!response.ok) {
    throw new ApiError(body?.error || "Could not load history.", response.status);
  }
  return body;
}

export async function fetchAnalysis(id) {
  const response = await fetch(`${API_BASE}/api/analyses/${id}`);
  const body = await parseJsonSafe(response);
  if (!response.ok) {
    throw new ApiError(body?.error || `Analysis ${id} not found.`, response.status);
  }
  return body;
}

export async function deleteAnalysis(id) {
  const response = await fetch(`${API_BASE}/api/analyses/${id}`, { method: "DELETE" });
  if (!response.ok && response.status !== 204) {
    const body = await parseJsonSafe(response);
    throw new ApiError(body?.error || `Could not delete analysis ${id}.`, response.status);
  }
  return true;
}

export { ApiError, API_BASE };
